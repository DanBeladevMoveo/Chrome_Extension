const text = document.querySelectorAll('h1','h2','p','span', 'a');
const images = document.querySelectorAll('img[src]','source');
const sources = document.querySelectorAll('source');
console.log('text is: ',text);
console.log('images is: ',images);
console.log('sources is: ',sources);
for (let i = 0; i < text.length; i++) {
    const element = text[i];
    element.innerHTML = `Nadav Zvaig was here ${new Date()}`;
}

for (let i = 0; i < images.length; i++) {
    const img = images[i];
    console.log('image src: ',img.src)
    console.log('image srcset: ',img.srcset)
    img.src  = img.src ?  "https://assets-global.website-files.com/5d83597c28a6017e74723191/5e451768ff66cf2a6792215c__0012_Nadav.jpg" : '';
    img.srcset = img.srcset ? "https://icons.iconarchive.com/icons/jonathan-rey/devices-printers/96/Pen-Drive-HP-165w-16GB-Red-icon.png" : '';
}

for (let i = 0; i < sources.length; i++) {
    const src = sources[i];
    src.srcset = "https://assets-global.website-files.com/5d83597c28a6017e74723191/5e451768ff66cf2a6792215c__0012_Nadav.jpg";
}