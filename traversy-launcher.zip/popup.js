// alert('im working')
// const text = document.querySelectorAll('h1','h2','p','span', 'a');
// const images = document.querySelectorAll('img[src]','source');
// console.log('text is: ',text);
// console.log('images is: ',images);
// for (let i = 0; i < text.length; i++) {
//     const element = text[i];
//     element.innerHTML = 'Nadav Zvaig was here 13/04/2021';
// }

// for (let i = 0; i < images.length; i++) {
//     const img = images[i];
//     img.src  = img.src ?  "https://icons.iconarchive.com/icons/jonathan-rey/devices-printers/96/Pen-Drive-HP-165w-16GB-Red-icon.png" : '';
//     img.srcset = img.srcset ? "https://icons.iconarchive.com/icons/jonathan-rey/devices-printers/96/Pen-Drive-HP-165w-16GB-Red-icon.png" : '';
// }